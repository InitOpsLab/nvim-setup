#!/usr/bin/env zsh
#
# jira.zsh - Jira CLI integration for zshell-setup
# Place in: ~/.zsh/functions/jira.zsh
#
# Usage:
#   jt              Create new Jira ticket in nvim
#   js              Submit current ticket file
#   jm              Show my open issues
#   jira-quick "x"  Quick ticket with just summary
#

# ============================================================================
# Aliases
# ============================================================================

alias jt='jira new'
alias je='jira epic'
alias jc='jira child'
alias jed='jira edit'
alias js='jira submit'
alias jm='jira my'
alias jv='jira view'
alias jo='jira open'
alias jb='jira buckets'
alias jp='jira projects'
alias jd='jira drafts'

# ============================================================================
# Quick Ticket Function
# ============================================================================

# Create and optionally submit a quick ticket with just a summary
# Usage: jira-quick "Fix the login bug"
jira-quick() {
    local summary="$*"
    if [[ -z "$summary" ]]; then
        echo "Usage: jira-quick <summary>"
        return 1
    fi
    
    local config_dir="${HOME}/.jira"
    local drafts_dir="${config_dir}/drafts"
    local project
    project=$(head -1 "$config_dir/projects" 2>/dev/null)
    
    if [[ -z "$project" ]]; then
        echo "No project configured. Run: jira setup"
        return 1
    fi
    
    mkdir -p "$drafts_dir"
    
    # Create filename with date and slug
    local datestamp slug ticket_file
    datestamp=$(date +%y%m%d)
    slug=$(echo "$summary" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//' | sed 's/-$//' | cut -c1-50)
    ticket_file="${drafts_dir}/${datestamp}-${slug}.jira.md"
    
    cat > "$ticket_file" << EOF
---
summary: $summary
bucket: DevOps Roadmap
project: $project
type: Task
labels: backend
assignee: me
estimate: 
sprint: backlog
---

## Description



## DoD

- [ ] 
EOF
    
    echo "✓ Created: $ticket_file"
    echo -n "Submit to Jira? [Y/n]: "
    read -r confirm
    if [[ ! "$confirm" =~ ^[Nn]$ ]]; then
        jira submit "$ticket_file"
    else
        echo "Edit with: nvim $ticket_file"
        echo "Submit with: jira submit \"$ticket_file\""
    fi
}

# ============================================================================
# FZF Integration
# ============================================================================

# Fuzzy search my Jira issues (requires fzf)
jira-fzf() {
    if ! command -v fzf &>/dev/null; then
        echo "fzf required. Install with: brew install fzf"
        return 1
    fi
    
    local config_dir="${HOME}/.jira"
    [[ -f "$config_dir/config" ]] || { echo "Run: jira setup"; return 1; }
    source "$config_dir/config"
    
    # Build API URL for scoped tokens
    local api_url="https://api.atlassian.com/ex/jira/${JIRA_CLOUD_ID}"
    local jql="assignee = currentUser() AND resolution = Unresolved ORDER BY updated DESC"
    local encoded_jql
    encoded_jql=$(printf '%s' "$jql" | jq -sRr @uri)
    
    local selected
    selected=$(curl -s -u "$JIRA_EMAIL:$JIRA_API_TOKEN" \
        -H "Content-Type: application/json" \
        "${api_url}/rest/api/3/search/jql?jql=${encoded_jql}&maxResults=50&fields=key,summary,status,priority" | \
        jq -r '.issues[]? | "\(.key)\t\(.fields.status.name)\t\(.fields.priority.name)\t\(.fields.summary)"' | \
        column -t -s $'\t' | \
        fzf --header="Select issue (Enter to open, Ctrl-V to view)" \
            --bind="ctrl-v:execute(jira view {1})+abort" \
            --preview-window=hidden)
    
    if [[ -n "$selected" ]]; then
        local key
        key=$(echo "$selected" | awk '{print $1}')
        echo "Selected: $key"
        echo -n "Action - [o]pen in browser / [v]iew / [c]opy key: "
        read -r action
        case "$action" in
            o*) jira open "$key" ;;
            v*) jira view "$key" ;;
            c*) echo -n "$key" | pbcopy 2>/dev/null || echo -n "$key" | xclip -sel clip 2>/dev/null
                echo "Copied: $key" ;;
            *)  echo "$key" ;;
        esac
    fi
}
alias jf='jira-fzf'

# ============================================================================
# Search Functions
# ============================================================================

# Search Jira issues with JQL
jira-search() {
    local jql="${*:-assignee = currentUser() AND resolution = Unresolved}"
    jira search "$jql"
}
alias jsearch='jira-search'

# Search issues in current sprint
jira-sprint() {
    jira search "assignee = currentUser() AND sprint in openSprints() ORDER BY priority DESC"
}

# ============================================================================
# Project/Bucket Helpers
# ============================================================================

# Switch default project
jira-project() {
    local project="$1"
    if [[ -z "$project" ]]; then
        echo "Current projects:"
        jira projects
        echo ""
        echo -n "Set default project: "
        read -r project
    fi
    
    if [[ -n "$project" ]]; then
        # Move selected project to top of list
        local projects_file="${HOME}/.jira/projects"
        if grep -q "^${project}$" "$projects_file" 2>/dev/null; then
            grep -v "^${project}$" "$projects_file" > "${projects_file}.tmp"
            echo "$project" | cat - "${projects_file}.tmp" > "$projects_file"
            rm -f "${projects_file}.tmp"
            echo "✓ Default project set to: $project"
        else
            echo "$project" | cat - "$projects_file" > "${projects_file}.tmp"
            mv "${projects_file}.tmp" "$projects_file"
            echo "✓ Added and set default: $project"
        fi
    fi
}

# Switch default bucket
jira-bucket() {
    local bucket="$1"
    if [[ -z "$bucket" ]]; then
        echo "Current buckets:"
        jira buckets
        echo ""
        echo "Options: 1=DevOps Roadmap, 2=Teams work, 3=Fire fighting, 4=Keeping the lights on"
        echo -n "Select bucket [1-4]: "
        read -r choice
        case "$choice" in
            1) bucket="DevOps Roadmap" ;;
            2) bucket="Teams work" ;;
            3) bucket="Fire fighting" ;;
            4) bucket="Keeping the lights on" ;;
            *) echo "Invalid choice"; return 1 ;;
        esac
    fi
    
    if [[ -n "$bucket" ]]; then
        local buckets_file="${HOME}/.jira/buckets"
        if grep -q "^${bucket}$" "$buckets_file" 2>/dev/null; then
            grep -v "^${bucket}$" "$buckets_file" > "${buckets_file}.tmp"
            echo "$bucket" | cat - "${buckets_file}.tmp" > "$buckets_file"
            rm -f "${buckets_file}.tmp"
            echo "✓ Default bucket set to: $bucket"
        fi
    fi
}

# ============================================================================
# Completion
# ============================================================================

# Basic completion for jira command
_jira_completion() {
    local -a commands
    commands=(
        'new:Create new ticket in nvim'
        'submit:Submit ticket file to Jira'
        'my:Show my open issues'
        'view:View issue details'
        'open:Open issue in browser'
        'projects:Manage projects'
        'buckets:Manage buckets'
        'setup:Configure credentials'
        'help:Show help'
    )
    
    if (( CURRENT == 2 )); then
        _describe -t commands 'jira commands' commands
    fi
}

compdef _jira_completion jira 2>/dev/null

# ============================================================================
# Status Check
# ============================================================================

# Check jira CLI is installed
if ! command -v jira &>/dev/null; then
    if [[ -x "$HOME/.local/bin/jira" ]]; then
        export PATH="$HOME/.local/bin:$PATH"
    else
        echo "⚠ jira CLI not found. Install from: https://github.com/InitOpsLab/jira-tool"
    fi
fi
