#!/usr/bin/env bash
#
# Jira shell aliases
# Add to your .zshrc or .bashrc:
#   source ~/.jira/aliases.sh
#

# Quick ticket creation - opens nvim with template
alias jt='jira new'
alias jira-ticket='jira new'

# Submit ticket
alias js='jira submit'

# My issues
alias jm='jira my'

# Quick function to create and submit in one go
jira-quick() {
    local summary="$*"
    if [[ -z "$summary" ]]; then
        echo "Usage: jira-quick <summary>"
        return 1
    fi
    
    # Create a quick ticket with just the summary
    local config_dir="${HOME}/.jira"
    local project
    project=$(head -1 "$config_dir/projects" 2>/dev/null)
    
    if [[ -z "$project" ]]; then
        echo "No project configured. Run: jira setup"
        return 1
    fi
    
    local ticket_file
    ticket_file=$(mktemp "${config_dir}/quick-XXXXXX.jira.md")
    
    cat > "$ticket_file" << EOF
---
project: $project
type: Task
summary: $summary
priority: Medium
assignee: me
---

## Description

Quick ticket created from command line.
EOF
    
    echo "Created ticket: $summary"
    read -rp "Submit to Jira? [Y/n]: " confirm
    if [[ ! "$confirm" =~ ^[Nn]$ ]]; then
        jira submit "$ticket_file"
    else
        echo "Saved: $ticket_file"
        echo "Edit and submit with: jira submit $ticket_file"
    fi
}

# Fuzzy search my issues (requires fzf)
jira-fzf() {
    if ! command -v fzf &>/dev/null; then
        echo "fzf required for this command"
        return 1
    fi
    
    local config_dir="${HOME}/.jira"
    source "$config_dir/config" 2>/dev/null || { echo "Run: jira setup"; return 1; }
    
    local selected
    selected=$(curl -s -u "$JIRA_EMAIL:$JIRA_API_TOKEN" \
        -H "Content-Type: application/json" \
        -X POST "${JIRA_URL}/rest/api/3/search" \
        -d '{"jql":"assignee = currentUser() AND resolution = Unresolved","maxResults":50,"fields":["key","summary","status"]}' | \
        jq -r '.issues[] | "\(.key)\t\(.fields.status.name)\t\(.fields.summary)"' | \
        fzf --delimiter='\t' --with-nth=1,3 --preview-window=hidden)
    
    if [[ -n "$selected" ]]; then
        local key
        key=$(echo "$selected" | cut -f1)
        echo "Selected: $key"
        read -rp "Action [o]pen / [v]iew / [c]opy: " action
        case "$action" in
            o*) jira open "$key" ;;
            v*) jira view "$key" ;;
            c*) echo -n "$key" | pbcopy 2>/dev/null || echo -n "$key" | xclip -sel clip 2>/dev/null; echo "Copied: $key" ;;
        esac
    fi
}
alias jf='jira-fzf'
