#!/usr/bin/env bash
#
# Install jira CLI and nvim integration
#

set -euo pipefail

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}==>${NC} $*"; }
success() { echo -e "${GREEN}✓${NC} $*"; }
warn() { echo -e "${YELLOW}⚠${NC} $*"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BOLD}Installing Jira CLI + Neovim + Zsh Integration${NC}\n"

# 1. Install CLI
log "Installing jira CLI..."
mkdir -p ~/.local/bin
cp "$SCRIPT_DIR/bin/jira" ~/.local/bin/jira
chmod +x ~/.local/bin/jira
success "CLI installed to ~/.local/bin/jira"

# 2. Setup jira config directory
log "Setting up ~/.jira directory..."
mkdir -p ~/.jira/templates
success "Config directory ready"

# 3. Install nvim plugin
log "Installing Neovim plugin..."
NVIM_CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}/nvim"
mkdir -p "$NVIM_CONFIG/lua/config"
mkdir -p "$NVIM_CONFIG/lua/lazy-plugins/plugins"

cp "$SCRIPT_DIR/nvim/lua/config/jira.lua" "$NVIM_CONFIG/lua/config/"
cp "$SCRIPT_DIR/nvim/lua/lazy-plugins/plugins/jira.lua" "$NVIM_CONFIG/lua/lazy-plugins/plugins/"
success "Neovim plugin installed"

# 4. Install zsh integration
log "Installing Zsh integration..."
if [[ -d ~/.zsh/functions ]]; then
    # User has zshell-setup structure
    cp "$SCRIPT_DIR/zsh/jira.zsh" ~/.zsh/functions/jira.zsh
    success "Zsh module installed to ~/.zsh/functions/jira.zsh"
    
    # Check if already sourced
    if ! grep -q "jira.zsh" ~/.zsh/functions.zsh 2>/dev/null; then
        echo -e "\n${YELLOW}Add to ~/.zsh/functions.zsh:${NC}"
        echo '  [[ -f ~/.zsh/functions/jira.zsh ]] && source ~/.zsh/functions/jira.zsh'
    fi
elif [[ -d ~/.zsh ]]; then
    cp "$SCRIPT_DIR/zsh/jira.zsh" ~/.zsh/jira.zsh
    success "Zsh module installed to ~/.zsh/jira.zsh"
    echo -e "\n${YELLOW}Add to ~/.zshrc:${NC}"
    echo '  [[ -f ~/.zsh/jira.zsh ]] && source ~/.zsh/jira.zsh'
else
    mkdir -p ~/.zsh/functions
    cp "$SCRIPT_DIR/zsh/jira.zsh" ~/.zsh/functions/jira.zsh
    success "Zsh module installed to ~/.zsh/functions/jira.zsh"
    echo -e "\n${YELLOW}Add to ~/.zshrc:${NC}"
    echo '  [[ -f ~/.zsh/functions/jira.zsh ]] && source ~/.zsh/functions/jira.zsh'
fi

# 5. Check PATH
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    warn "~/.local/bin not in PATH"
    echo "Add to ~/.zshrc (if not already there):"
    echo '  export PATH="$HOME/.local/bin:$PATH"'
fi

echo ""
echo -e "${BOLD}${GREEN}Installation complete!${NC}"
echo ""
echo -e "${BOLD}Next steps:${NC}"
echo "  1. Source your zsh config: source ~/.zshrc"
echo "  2. Run: jira setup"
echo "  3. Add your project: jira projects add DEVOPS"
echo "  4. Create a ticket: jt"
echo ""
echo -e "${BOLD}Zsh Aliases:${NC}"
echo "  jt          New ticket (jira new)"
echo "  js          Submit ticket"
echo "  jm          My issues"
echo "  jf          Fuzzy search issues (fzf)"
echo "  jira-quick  Quick ticket from CLI"
echo ""
echo -e "${BOLD}Neovim:${NC}"
echo "  :Lazy sync  Reload plugins"
echo "  :Jira new   Create ticket"
echo "  :Jira submit Submit current buffer"
echo ""
