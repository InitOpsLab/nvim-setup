# 🎫 Jira CLI + Neovim Integration

Write Jira tickets in Neovim with markdown, submit with `:Jira submit`.

## Quick Start

```bash
# Install
./install.sh

# Setup credentials (uses scoped API token)
jira setup

# Add your project
jira projects add DEVOPS

# Create a ticket
jira new
# or in nvim: :Jira new
```

## Scoped API Token Setup

This tool uses **scoped API tokens** for better security. During `jira setup`, you'll need to:

1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click **"Create API token with scopes"**
3. Select **Jira** as the app
4. Add these scopes:
   - `read:jira-work` - View issues
   - `write:jira-work` - Create/update issues
   - `read:jira-user` - User info for assignee
   - `read:me` - Verify connection
5. Create and copy the token

The tool automatically fetches your Cloud ID and uses the correct API endpoint.

## Features

- **Terminal command** `jira` for full CLI workflow
- **Neovim integration** with `:Jira` commands
- **Markdown templates** with YAML frontmatter
- **HoneyBook custom fields** support
- **Shell aliases** for quick access

## CLI Commands

| Command | Description |
|---------|-------------|
| `jira new` | Open nvim with ticket template |
| `jira submit <file>` | Submit ticket to Jira |
| `jira my` | Show your open issues |
| `jira view <KEY>` | View issue details |
| `jira open <KEY>` | Open issue in browser |
| `jira projects` | Manage project list |
| `jira buckets` | Manage bucket options |
| `jira setup` | Configure credentials |

## Neovim Commands

| Command | Description |
|---------|-------------|
| `:Jira submit` or `:Jira s` | Submit current buffer |
| `:Jira new` or `:Jira n` | Create new ticket |
| `:Jira my` or `:Jira m` | Show my issues |
| `:Jira view` or `:Jira v` | View issue under cursor |
| `:Jira open` or `:Jira o` | Open issue in browser |

## Keymaps (in .jira.md files)

| Key | Action |
|-----|--------|
| `<leader>js` | Submit ticket |
| `<leader>jv` | View issue |
| `<leader>jo` | Open in browser |

## Ticket Template

```markdown
---
# Project - Uncomment ONE:
project: DEVOPS
# project: INFRA

type: Task
summary: Your ticket title
priority: Medium
labels: 
assignee: me
sprint: 
estimate: 2h

# Environment - Uncomment ONE:
environment: Production
# environment: Staging
# environment: Development

# Bucket - Uncomment ONE:
bucket: DevOps Roadmap
# bucket: Teams work
# bucket: Fire fighting
# bucket: Keeping the lights on

testing_scope: 
---

## Description

Your description with **markdown** support.

## Acceptance Criteria

- [ ] First criterion
- [ ] Second criterion
```

## Managing Projects & Buckets

```bash
# Projects
jira projects              # List
jira projects add DEVOPS   # Add
jira projects remove DEVOPS
jira projects fetch        # Fetch all from Jira

# Buckets  
jira buckets               # List
jira buckets add "New Bucket"
jira buckets reset         # Reset to defaults
jira buckets ids           # Show ID mapping
```

## Configuration

All config stored in `~/.jira/`:

```
~/.jira/
├── config          # Credentials (JIRA_SITE, JIRA_CLOUD_ID, JIRA_EMAIL, JIRA_API_TOKEN)
├── projects        # Project keys (one per line)
├── buckets         # Bucket options (one per line)
├── templates/      # Custom templates
└── aliases.sh      # Shell aliases
```

### Config File Format

```bash
# ~/.jira/config
JIRA_SITE="honeybook.atlassian.net"
JIRA_CLOUD_ID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
JIRA_EMAIL="you@company.com"
JIRA_API_TOKEN="your-scoped-token"
JIRA_ACCOUNT_ID="your-account-id"
```

## Shell Aliases

Add to your `.zshrc` or `.bashrc`:

```bash
source ~/.jira/aliases.sh
```

Then use:
- `jt` - Quick new ticket
- `js` - Submit ticket
- `jm` - My issues
- `jf` - Fuzzy search issues (requires fzf)
- `jira-quick "summary"` - Create and submit quick ticket

## Requirements

- `jq` - JSON processing
- `curl` - HTTP requests
- `nvim` - Neovim
- `fzf` - (optional) for fuzzy search

```bash
# macOS
brew install jq curl neovim fzf

# Ubuntu
sudo apt install jq curl neovim fzf
```

## Workflow

1. **Setup** (one time):
   ```bash
   jira setup
   jira projects add DEVOPS
   ```

2. **Create ticket**:
   ```bash
   jira new
   # Opens nvim with template
   ```

3. **Edit in nvim**:
   - Fill in the template
   - Save and quit (`:wq`)

4. **Submit**:
   - Prompted after closing nvim, or
   - `:Jira submit` from within nvim

5. **Track**:
   ```bash
   jira my           # Your issues
   jira view DEVOPS-123
   jira open DEVOPS-123
   ```
